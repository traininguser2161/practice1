﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Practice1
{
    public class Class1
    {
        public void Test()
        {
            Console.WriteLine("Demo");
        }
    }
}
